CRANFORD TOUR STOP ILLUSTRATIONS — FIGMA IMPORT

Import: unzip this folder, then drag the five numbered PNG/SVG files onto your Figma canvas (or use File > Place image for PNGs and drag the SVGs). The README and manifest are not design assets.

01 Droescher’s Mill: original transparent PNG, 1448 × 1086 pixels.
02 Greystone: original transparent PNG, 1448 × 1086 pixels.
03 Rahway River: original transparent PNG, 1448 × 1086 pixels.
04 First Baptist Church: scalable editable SVG, 1440 × 1440 default size.
05 Cranford Hotel: scalable editable SVG, 1440 × 1296 default size.

All artwork has a transparent background. The three PNGs are byte-for-byte copies of the app originals, without upscaling, recoloring, or a gray overlay. Their maximum native resolution is 1448 × 1086; larger raster exports cannot add original detail. Church and hotel SVGs are translations of the current SwiftUI Canvas paths and colors, preserving their simple architectural style. SVGs remain sharp when enlarged and may be ungrouped in Figma. Minor rasterizer differences from SwiftUI are possible.

Number circles and map leader lines are separate app UI, deliberately excluded from the illustrations. No new artwork or stop details have been invented. No production files were changed. This package has been exported locally; it has not been uploaded to a Figma file because a Figma connector is unavailable in this session.

Source: aviciedo/CranfordHistoricalWalk
Commit: 0eccfab86e1226f6d0177e2beb70b463b5e3ccd0 (build 55)
Vector drawing source: CranfordHistoricalAR/Views/StopsView.swift

PNG-alternatives contains transparent 1440-pixel-wide renders of the church and hotel if you prefer to import all five as PNGs. Use these instead of the matching SVGs, not in addition to them.
